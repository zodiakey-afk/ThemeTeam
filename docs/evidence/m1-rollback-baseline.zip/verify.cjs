const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');

const frontend = path.resolve(__dirname, '..');
const root = path.dirname(frontend);
const evidence = path.join(root, 'docs/evidence');
const hash = file => fs.existsSync(file) ? crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex') : null;
const stateFile = path.join(root, 'themeteam/core/workspace_state.json');
const before = hash(stateFile);
const commands = [];
let passed = true;
for (const script of ['typecheck', 'test:unit', 'build', 'test:e2e']) {
  const result = spawnSync(process.execPath, [process.env.npm_execpath, '--offline', 'run', script], {
    cwd: frontend, encoding: 'utf8', env: { ...process.env, npm_config_offline: 'true' },
  });
  const log = path.join(evidence, `w03-${script.replace(':', '-')}.log`);
  fs.writeFileSync(log, `${result.stdout || ''}${result.stderr || ''}${result.error || ''}`);
  commands.push({ command: `npm --offline run ${script}`, cwd: frontend, exitCode: result.status,
    log: path.relative(root, log), sha256: hash(log) });
  console.log(`${script}: ${result.status === 0 ? 'PASS' : 'FAIL'}`);
  if (result.status !== 0) { passed = false; break; }
}
const lock = JSON.parse(fs.readFileSync(path.join(frontend, 'package-lock.json'), 'utf8'));
const licenses = Object.entries(lock.packages).filter(([key]) => key).map(([key, value]) => ({
  packagePath: key, version: value.version, license: value.license || null,
  installed: fs.existsSync(path.join(frontend, key, 'package.json')),
}));
const licenseReport = path.join(evidence, 'w03-licenses.json');
fs.writeFileSync(licenseReport, JSON.stringify(licenses, null, 2));
const missingLicenses = licenses.filter(item => !item.license);
const findings = [];
const patterns = [/\bsk-[A-Za-z0-9_-]{16,}\b/g, /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g,
  /(?:api[_-]?key|password|secret)\s*[:=]\s*["'][^"'\r\n]{12,}["']/gi];
const excluded = new Set(['node_modules', '.git', '.cache', '__pycache__', 'dist', 'output']);
let scannedFiles = 0;
function scan(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const file = path.join(directory, entry.name);
    if (entry.isDirectory()) { if (!excluded.has(entry.name)) scan(file); continue; }
    if (!/\.(?:py|js|cjs|ts|tsx|json|yaml|md|html|css)$/.test(entry.name) || file === __filename) continue;
    scannedFiles++;
    const content = fs.readFileSync(file, 'utf8');
    for (const [index, expression] of patterns.entries()) {
      expression.lastIndex = 0;
      if (expression.test(content)) findings.push({ file: path.relative(root, file), rule: index + 1 });
    }
  }
}
scan(root);
const after = hash(stateFile);
passed = passed && before === after && missingLicenses.length === 0 && findings.length === 0;
const report = { result: passed ? 'passed' : 'failed', date: new Date().toISOString(), node: process.version,
  platform: `${process.platform}/${process.arch}`, commands, lockSha256: hash(path.join(frontend, 'package-lock.json')),
  licenses: { count: licenses.length, missing: missingLicenses, report: 'docs/evidence/w03-licenses.json', sha256: hash(licenseReport) },
  secretScan: { scannedFiles, findings, limitation: 'Heuristic credential scan, not a comprehensive PII or secret audit; generated output and dependencies excluded.' },
  workspaceIntegrity: { before, after, unchanged: before === after },
  offline: 'npm offline mode with already-installed locked dependencies; not a network-isolated install or OS egress proof.' };
fs.writeFileSync(path.join(evidence, 'w03-verification.json'), JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
if (!passed) process.exitCode = 1;
