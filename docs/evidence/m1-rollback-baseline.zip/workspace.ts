import { createStore } from 'zustand/vanilla';
import Ajv2020 from 'ajv/dist/2020';
import schema from './workspace-schema.json';
import errorSchema from './error-schema.json';
import type { ClientState, Outcome, Selection, Snapshot } from './types';

const validateSnapshot = new Ajv2020({ allErrors: false, strict: false }).compile<Snapshot>(schema);
const validateError = new Ajv2020({ allErrors: false, strict: false }).compile<{ error: { code: string; message: string } }>(errorSchema);
const collections = { agent: 'agents', task: 'tasks', room: 'rooms', meeting: 'meetings', document: 'documents' } as const;
export function exists(snapshot: Snapshot | null, selection: Selection | null): selection is Selection {
  return !!snapshot && !!selection && snapshot[collections[selection.kind]].some(item => item.id === selection.id);
}
const same = (a: Selection | null, b: Selection | null) => a?.kind === b?.kind && a?.id === b?.id;

export function createWorkspaceController(fetcher: typeof fetch = fetch, timeoutMs = 10000) {
  const store = createStore<ClientState>(() => ({ snapshot: null, selection: null, previousSelection: null,
    inspectorOpen: false, pending: 0, error: null, dirty: false, uncertain: false, disposed: false }));
  let tail: Promise<unknown> = Promise.resolve();
  let active: AbortController | null = null;

  function request(path: string, effect: 'read' | 'write' | 'save' | 'reload', body?: object): Promise<Outcome> {
    if (store.getState().disposed) return Promise.resolve('disposed');
    store.setState(s => ({ pending: s.pending + 1 }));
    const job = async (): Promise<Outcome> => {
      if (store.getState().disposed) return 'disposed';
      if (store.getState().uncertain && effect !== 'read') {
        store.setState(s => ({ pending: s.pending - 1 }));
        return 'unknown';
      }
      active = new AbortController();
      const abort = active;
      let timer: ReturnType<typeof setTimeout> | undefined;
      let onAbort: () => void = () => undefined;
      let definite = false;
      if (!store.getState().uncertain) store.setState({ error: null });
      try {
        const { response, data } = await Promise.race([
          (async () => {
            const response = await fetcher(path, { method: effect === 'read' ? 'GET' : 'POST', signal: abort.signal,
              headers: { 'Content-Type': 'application/json' }, ...(effect === 'read' ? {} : { body: JSON.stringify(body || {}) }) });
            return { response, data: await response.json() as unknown };
          })(),
          new Promise<never>((_, reject) => {
            onAbort = () => reject(new Error('请求中断或超时'));
            abort.signal.addEventListener('abort', onAbort, { once: true });
            timer = setTimeout(() => abort.abort(), timeoutMs);
          }),
        ]);
        if (!response.ok) {
          const error = validateError(data) ? data.error : null;
          const known = ['invalid_payload', 'forbidden', 'not_found', 'conflict', 'payload_too_large'];
          definite = !!error?.code && ((response.status >= 400 && response.status < 500 && known.includes(error.code)) ||
            (response.status === 500 && error.code === 'storage_error' && (effect === 'save' || effect === 'reload')));
          throw new Error(error?.code || `HTTP ${response.status}`);
        }
        if (!validateSnapshot(data)) throw new Error('工作区响应结构无效');
        if (store.getState().disposed) return 'disposed';
        const current = store.getState();
        const selection = exists(data, current.selection) ? current.selection : null;
        store.setState({ snapshot: data, selection,
          previousSelection: exists(data, current.previousSelection) ? current.previousSelection : null,
          inspectorOpen: !!selection && current.inspectorOpen,
          dirty: effect === 'save' || effect === 'reload' ? false : effect === 'write' ? true : current.dirty,
          error: current.uncertain ? current.error : null });
        return 'success';
      } catch (error) {
        if (store.getState().disposed) return 'disposed';
        const unknown = effect !== 'read' && !definite;
        store.setState(s => ({ error: unknown ? '操作结果未知，已暂停本会话写入。请在服务端确认结束后重新打开工作区。' : String(error),
          uncertain: s.uncertain || unknown, dirty: s.dirty || unknown }));
        return unknown ? 'unknown' : 'rejected';
      } finally {
        clearTimeout(timer);
        abort.signal.removeEventListener('abort', onAbort);
        if (active === abort) active = null;
        if (!store.getState().disposed) store.setState(s => ({ pending: Math.max(0, s.pending - 1) }));
      }
    };
    const result = tail.then(job);
    tail = result.catch(() => undefined);
    return result;
  }
  return {
    store,
    load: () => request('/api/state', 'read'),
    save: () => request('/api/save', 'save'),
    reload: () => request('/api/reload', 'reload'),
    createAgent: (body: object) => request('/api/agents', 'write', body),
    createTask: (body: object) => request('/api/tasks', 'write', body),
    setTaskStatus: (id: string, status: string) => request(`/api/tasks/${encodeURIComponent(id)}/status`, 'write', { status }),
    select(selection: Selection) {
      const state = store.getState();
      if (state.disposed || !exists(state.snapshot, selection)) return;
      store.setState({ selection, previousSelection: same(state.selection, selection) ? state.previousSelection : state.selection, inspectorOpen: true });
    },
    closeInspector() { if (!store.getState().disposed) store.setState({ inspectorOpen: false }); },
    back() {
      const state = store.getState();
      if (state.disposed) return;
      const previous = exists(state.snapshot, state.previousSelection) ? state.previousSelection : null;
      store.setState({ selection: previous, previousSelection: null, inspectorOpen: !!previous });
    },
    dispose() {
      if (store.getState().disposed) return;
      active?.abort();
      store.setState({ disposed: true, pending: 0 });
    },
  };
}
export type WorkspaceController = ReturnType<typeof createWorkspaceController>;
