import type { StoreApi } from 'zustand/vanilla';
import type { ClientState, Selection, Snapshot } from './types';

export interface SceneAdapter {
  update(snapshot: Snapshot | null, selection: Selection | null): void;
  destroy(): void;
}

// The W04 Phaser adapter consumes this contract; it does not own business state.
export function connectScene(store: StoreApi<ClientState>, adapter: SceneAdapter) {
  let stopped = false;
  const state = store.getState();
  adapter.update(state.snapshot, state.selection);
  const unsubscribe = store.subscribe((next, previous) => {
    if (!stopped && !next.disposed && (next.snapshot !== previous.snapshot || next.selection !== previous.selection)) {
      adapter.update(next.snapshot, next.selection);
    }
  });
  return () => {
    if (stopped) return;
    stopped = true;
    unsubscribe();
    adapter.destroy();
  };
}
